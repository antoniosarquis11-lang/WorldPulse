WorldPulse static MVP

How to publish on Netlify:
1. Unzip this folder.
2. Drag the whole folder into Netlify's manual deploy area.
3. The entry file is index.html.

Notes:
- This is a static frontend prototype: no backend, no login, no database.
- Globe data loads from jsDelivr CDN using D3 + world-atlas.
- It includes homepage, Discover, Stories, Story Globe, Compare, Daily Brief and Learn.
- Profile has been removed.
